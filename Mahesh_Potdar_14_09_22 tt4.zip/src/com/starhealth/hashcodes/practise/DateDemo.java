package com.starhealth.hashcodes.practise;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateDemo {
	
	public static void main(String[] args) {
		
		
	System.out.println(LocalDate.now());
	
	LocalDate object = LocalDate.of(2000, 05, 24);
	
	System.out.println(object.getDayOfWeek());
	
	Scanner sc = new Scanner(System.in);
	
	
	String dd = sc.nextLine();
	
	
	DateTimeFormatter hel = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	
	LocalDate obj3 = LocalDate.parse(dd,hel);
	
	System.out.println(obj3);
	
	
		
		
		
	}

}
