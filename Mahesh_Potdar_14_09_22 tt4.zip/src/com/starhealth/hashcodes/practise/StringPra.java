package com.starhealth.hashcodes.practise;

public class StringPra {
	
	public static void main (String[] args) {
		
		String st1 = "Aanand";
		
		String st2 = "Chowdary";	
		
		System.out.println(st1 == st2);
		
		String st4 = new String("Test String");
		
		String st5 = new String("String");
		
		System.out.println(st4.equals(st5));
		
		System.out.println(st2 = st2.concat(st5));
		
		System.out.println(st2);
		
		String s5 = new String("B");  
		String s6 = new String("A");
		
		System.out.println(s5.compareTo(s6));
		
		StringBuffer ob6 = new StringBuffer("Coffee");
		
		ob6.append("Cup");
		
		System.out.println(ob6.append("Hello"));
		
		System.out.println(ob6.replace(0, 2,"ka"));
	}

}
