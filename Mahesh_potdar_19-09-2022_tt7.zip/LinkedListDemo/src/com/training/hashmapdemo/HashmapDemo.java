package com.training.hashmapdemo;

import java.util.Set;
import java.util.HashMap;

public class HashmapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,Employee> map = new HashMap<>();
		map.put(102, new Employee(102,"ravi",23000.0));
		map.put(100, new Employee(100,"ram",25000.0));
		map.put(109, new Employee(109,"vasu",28000.0));
		map.put(101, new Employee(101,"aaron",29000.0));
		System.out.println(map);
		System.out.println(map.keySet());
		System.out.println(map.values());
		System.out.println(map.get(101));
		Set<Integer> keySet = map.keySet();
		for(Integer key:keySet) {
			System.out.println(key +" "+map.get(key));
		}

	}

}
