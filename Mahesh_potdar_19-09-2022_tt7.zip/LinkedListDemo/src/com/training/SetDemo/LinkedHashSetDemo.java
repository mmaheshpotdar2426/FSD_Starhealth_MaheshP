package com.training.SetDemo;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet<Employee> setEmp = new LinkedHashSet<Employee>();
		setEmp.add(new Employee(210,"varun",20000.0));
		setEmp.add(new Employee(208,"vasu",22000.0));
		setEmp.add(new Employee(219,"ravi",21000.0));
		setEmp.add(new Employee(213,"ram",22500.0));
		System.out.println(setEmp);

	}

}
