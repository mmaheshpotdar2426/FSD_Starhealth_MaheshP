package com.training.SetDemo;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Employee> tree = new TreeSet<Employee>(new MyComparator());
		tree.add(new Employee(211,"ravi",12000.0));
		tree.add(new Employee(208,"ram",22000.0));
		tree.add(new Employee(213,"vasu",17000.0));
		tree.add(new Employee(215,"aaron",12000.0));
		
		System.out.println(tree);
	}

}
