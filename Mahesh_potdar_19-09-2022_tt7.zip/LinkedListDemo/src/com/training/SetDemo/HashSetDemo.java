package com.training.SetDemo;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<Integer> set = new HashSet<Integer>();
		set.add(103);
		set.add(104);
		set.add(105);
		set.add(106);
		set.add(107);
		set.add(null);
		set.add(103);
		System.out.println(set);
		
		HashSet<Employee> setEmp = new HashSet<Employee>();
		setEmp.add(new Employee(101,"Varun",12000.0));
		setEmp.add(new Employee(102,"Araon",15000.0));
		setEmp.add(new Employee(100,"Vasu",16000.0));
		setEmp.add(new Employee(104,"Ram",18000.0));
		System.out.println(setEmp);

	}

}
