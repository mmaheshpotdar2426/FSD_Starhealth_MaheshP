//Question 14.
public class Animals {
    void eat(){
        System.out.println("Inside eat Method of Base Class 'Animals'.");
    }
}
