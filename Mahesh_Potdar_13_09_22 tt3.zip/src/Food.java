
public class Food {
    public String type ="Indian";
    //private String meal ="Medium";

    public void giveFood(){
        System.out.println("Food given to XYZ Orphanage.");
    }

	/*
	 * private void takeFood(){
	 * System.out.println("Food is taken for Office Members."); }
	 */
}
