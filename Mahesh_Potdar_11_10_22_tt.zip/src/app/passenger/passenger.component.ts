import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger',
  templateUrl: './passenger.component.html',
  styleUrls: ['./passenger.component.css']
})
export class PassengerComponent implements OnInit {
  Name:string="Sumit"
  Ticket:string="OKLMO20"
  Seat:string="25A"

  check():void{
    alert("Passenger details not available")

  }

  constructor() { }

  ngOnInit(): void {
  }

}
