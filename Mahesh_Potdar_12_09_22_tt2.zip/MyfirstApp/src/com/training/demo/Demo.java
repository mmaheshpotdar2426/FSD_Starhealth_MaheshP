package com.training.demo;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 1;
		byte id = 12;
		short marks = 100;
		double score = 34.89;
		long rank = 62536756;
		float totalMarks= 67.23f;
		char letter = 'A';
		boolean value = true;
		String studentName = "Bhuvanesh";
		int n_cast = (int)score;
		
		System.out.println(n);
		System.out.println(id);
		System.out.println(marks);
		System.out.println(score);
		System.out.println(rank);
		System.out.println(totalMarks);
		System.out.println(letter);
		System.out.println(value);
		System.out.println(studentName);
		System.out.println("Type casting - " + n_cast);
	}

}
