import { ApplicationRef, Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'starapp';
  PaymentData="Payment is done"
  mycolor="Purple"
 Flag:boolean=true
 Ldate= new Date (2000,5,21)
 choice:string=""
 data:string=""
 names:string[]=["javeed","Sumit","mahesh","yash"]

 dataFromCostumer:string=""

 getData(data:any){

  // alert ("Alert message")
    
  console.log(data);
   this.dataFromCostumer=data;
}

}






