package com.training.multithreading;

public class WaitSleep {
	private static Object obj = new Object();   
	
	public static void main(String[] args) throws InterruptedException{
		Thread.sleep(3000);
		
		System.out.println(Thread.currentThread().getName() + "Thread will start after 3 seconds");
		
		synchronized (obj) {
			obj.wait(8000);
			System.out.println(obj + "obj is in waiting state start's again after 8 seconds");
		}
	}
}
